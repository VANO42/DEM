﻿using Microsoft.Win32;
using ShoeStore.Data;
using ShoeStore.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace ShoeStore.Views
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductWindow.xaml
    /// </summary>
    public partial class AddEditProductWindow : Window
    {
        // Приватные поля
        private Product _product;           // null = режим добавления, не-null = режим редактирования
        private string? _imageFileName;      // Имя сохранённого файла изображения

        public AddEditProductWindow(Product product)
        {
            InitializeComponent();
            _product = product;

            // Загружаем выпадающие списки
            LoadDropdowns();

            if (product != null)
            {
                // ===== РЕЖИМ РЕДАКТИРОВАНИЯ =====
                Title = "Редактирование товара";
                TbTitle.Text = "Редактирование товара";

                // Заполняем поля данными из объекта Product
                TbArticle.Text = product.Article;
                TbArticle.IsReadOnly = true;  // Артикул нельзя менять при редактировании
                TbName.Text = product.Name;
                TbDescription.Text = product.Description ?? "";
                TbPrice.Text = product.Price.ToString("F2");
                TbUnit.Text = product.Unit;
                TbQuantity.Text = product.StockQuantity.ToString();
                TbDiscount.Text = product.Discount.ToString();

                // Выбираем нужные значения в ComboBox через LINQ
                SelectComboBoxItem(CmbCategory, product.CategoryId);
                SelectComboBoxItem(CmbManufacturer, product.ManufacturerId);
                SelectComboBoxItem(CmbSupplier, product.SupplierId);

                // Загружаем изображение
                _imageFileName = product.ImagePath;
                LoadPreviewImage();
            }
            else
            {
                // ===== РЕЖИМ ДОБАВЛЕНИЯ =====
                Title = "Добавление товара";
                TbTitle.Text = "Добавление товара";

                // Скрываем кнопку удаления
                BtnDelete.Visibility = Visibility.Collapsed;

                // Генерируем новый артикул
                TbArticle.Text = GenerateArticle();
            }
        }

        /// <summary>
        /// Загружает данные в выпадающие списки.
        /// </summary>
        private void LoadDropdowns()
        {
            using (var db = new ShoeStoreContext())
            {
                // ItemsSource — привязываем коллекцию к ComboBox
                // DisplayMemberPath — какое свойство показывать в списке
                CmbCategory.ItemsSource = db.Categories.OrderBy(c => c.Name).ToList();
                CmbCategory.DisplayMemberPath = "Name";

                CmbManufacturer.ItemsSource = db.Manufacturers.OrderBy(m => m.Name).ToList();
                CmbManufacturer.DisplayMemberPath = "Name";

                CmbSupplier.ItemsSource = db.Suppliers.OrderBy(s => s.Name).ToList();
                CmbSupplier.DisplayMemberPath = "Name";
            }
        }

        /// <summary>
        /// Выбирает элемент в ComboBox по ID.
        /// </summary>
        private void SelectComboBoxItem(ComboBox combo, int? id)
        {
            if (id == null) return;

            // Перебираем элементы ComboBox, ищем совпадение по Id
            foreach (var item in combo.Items)
            {
                // Используем рефлексию для получения Id (у всех моделей есть Id)
                var property = item.GetType().GetProperty("Id");
                if (property != null && (int)property.GetValue(item) == id.Value)
                {
                    combo.SelectedItem = item;
                    return;
                }
            }
        }

        /// <summary>
        /// Выбор файла изображения.
        /// </summary>
        private void BtnChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*",
                Title = "Выберите изображение товара"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    // Копируем файл в папку Images с уникальным именем
                    string imagesFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images");
                    Directory.CreateDirectory(imagesFolder);

                    string extension = Path.GetExtension(dialog.FileName);
                    string newFileName = $"{DateTime.Now:yyyyMMddHHmmss}_{Guid.NewGuid():N}{extension}";
                    string destPath = Path.Combine(imagesFolder, newFileName);

                    File.Copy(dialog.FileName, destPath, true);

                    // Сохраняем имя файла
                    _imageFileName = newFileName;
                    TbImagePath.Text = newFileName;

                    // Показываем предпросмотр
                    LoadPreviewImage();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при копировании файла: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        /// <summary>
        /// Загружает изображение в элемент предпросмотра.
        /// </summary>
        private void LoadPreviewImage()
        {
            if (string.IsNullOrEmpty(_imageFileName))
            {
                ImgPreview.Source = null;
                return;
            }

            try
            {
                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", _imageFileName);
                if (File.Exists(fullPath))
                {
                    ImgPreview.Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(fullPath));
                }
            }
            catch
            {
                ImgPreview.Source = null;
            }
        }

        /// <summary>
        /// Сохранение товара (добавление или обновление).
        /// </summary>
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (!ValidateInput(out string error))
            {
                TbErrors.Text = error;
                return;
            }

            try
            {
                using (var db = new ShoeStoreContext())
                {
                    if (_product == null)
                    {
                        // ===== ДОБАВЛЕНИЕ НОВОГО ТОВАРА =====
                        _product = new Product
                        {
                            Article = TbArticle.Text.Trim()
                        };
                        db.Products.Add(_product);
                    }
                    else
                    {
                        // ===== РЕДАКТИРОВАНИЕ СУЩЕСТВУЮЩЕГО =====
                        // Attach — прикрепляем отсоединённую сущность к контексту
                        db.Products.Attach(_product);
                    }

                    // Заполняем все поля
                    _product.Name = TbName.Text.Trim();
                    _product.Description = TbDescription.Text.Trim();
                    _product.Price = decimal.Parse(TbPrice.Text);
                    _product.Unit = TbUnit.Text.Trim();
                    _product.StockQuantity = int.Parse(TbQuantity.Text);
                    _product.Discount = int.Parse(TbDiscount.Text);
                    _product.CategoryId = (CmbCategory.SelectedItem as Category)?.Id;
                    _product.ManufacturerId = (CmbManufacturer.SelectedItem as Manufacturer)?.Id;
                    _product.SupplierId = (CmbSupplier.SelectedItem as Supplier)?.Id;
                    _product.ImagePath = _imageFileName;

                    // Сохраняем изменения в БД
                    db.SaveChanges();
                }

                // Закрываем окно с результатом true
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Удаление товара.
        /// </summary>
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_product == null) return;

            var result = MessageBox.Show(
                $"Удалить товар \"{_product.Name}\"?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                using (var db = new ShoeStoreContext())
                {
                    bool inOrders = db.OrderItems.Any(oi => oi.ProductArticle == _product.Article);
                    if (inOrders)
                    {
                        MessageBox.Show("Товар нельзя удалить — он есть в заказах.",
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    var p = db.Products.Find(_product.Article);
                    if (p != null)
                    {
                        // Удаляем файл изображения
                        if (!string.IsNullOrEmpty(p.ImagePath))
                        {
                            string imgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images", p.ImagePath);
                            if (File.Exists(imgPath)) File.Delete(imgPath);
                        }

                        db.Products.Remove(p);
                        db.SaveChanges();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => Close();

        /// <summary>
        /// Валидация введённых данных.
        /// </summary>
        private bool ValidateInput(out string error)
        {
            if (string.IsNullOrWhiteSpace(TbArticle.Text)) { error = "Введите артикул"; return false; }
            if (string.IsNullOrWhiteSpace(TbName.Text)) { error = "Введите наименование"; return false; }
            if (!decimal.TryParse(TbPrice.Text, out decimal price) || price < 0) { error = "Некорректная цена"; return false; }
            if (!int.TryParse(TbQuantity.Text, out int qty) || qty < 0) { error = "Некорректное количество"; return false; }
            if (!int.TryParse(TbDiscount.Text, out int disc) || disc < 0 || disc > 100) { error = "Скидка должна быть 0-100%"; return false; }
            if (CmbCategory.SelectedItem == null) { error = "Выберите категорию"; return false; }
            error = null; return true;
        }

        /// <summary>
        /// Генерация нового артикула.
        /// </summary>
        private string GenerateArticle()
        {
            var rnd = new Random();
            return $"{(char)rnd.Next('A', 'Z' + 1)}{rnd.Next(100, 999)}{(char)rnd.Next('A', 'Z' + 1)}{rnd.Next(0, 9)}";
        }
    }
}
