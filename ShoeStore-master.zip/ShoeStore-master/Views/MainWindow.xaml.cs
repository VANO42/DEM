﻿using Microsoft.EntityFrameworkCore;
using ShoeStore.Data;
using ShoeStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShoeStore.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // ========== ПОЛЯ КЛАССА ==========

        /// <summary>
        /// Полный список товаров из БД.
        /// Хранится в памяти для быстрой фильтрации/сортировки без повторных запросов.
        /// List<Product> — обобщённая коллекция (generic), тип Product указан в угловых скобках.
        /// </summary>
        private List<Product> _allProducts;

        /// <summary>
        /// Флаг защиты от открытия нескольких окон редактирования.
        /// true = окно редактирования уже открыто.
        /// </summary>
        private bool _isEditWindowOpen;

        /// <summary>
        /// Словарь быстрого поиска для определения роли пользователя.
        /// Dictionary<TKey, TValue> — коллекция пар ключ-значение.
        /// Ключ — ID роли, значение — флаг "является ли менеджером или админом".
        /// </summary>
        private static readonly Dictionary<int, bool> ManagerOrAdminRoles = new()
        {
            { 1, true },  // Администратор
            { 2, true }   // Менеджер
        };

        // ========== КОНСТРУКТОР ==========

        /// <summary>
        /// Конструктор главного окна.
        /// Выполняется при создании окна (один раз).
        /// </summary>
        public MainWindow()
        {
            // Инициализация XAML-компонентов (обязательная строка!)
            InitializeComponent();

            // Загружаем данные из БД
            LoadProducts();

            // Настраиваем видимость элементов в зависимости от роли
            SetupUserInterface();
        }

        /// <summary>
        /// Загружает все товары из базы данных.
        /// Использует Include() для жадной загрузки связанных данных.
        /// </summary>
        private void LoadProducts()
        {
            try
            {
                using (var db = new ShoeStoreContext())
                {
                    // Include() — метод расширения EF Core, выполняет JOIN в SQL-запросе.
                    // "Жадная загрузка" (eager loading) — связанные данные загружаются сразу,
                    // а не при первом обращении (ленивая загрузка).
                    // Лямбда-выражение p => p.Category указывает навигационное свойство.
                    _allProducts = db.Products
                        .Include(p => p.Category)       // Загружаем категорию
                        .Include(p => p.Supplier)       // Загружаем поставщика
                        .Include(p => p.Manufacturer)   // Загружаем производителя
                        .ToList();                      // Материализуем запрос в List<Product>

                    // Заполняем комбобокс поставщиков
                    LoadSupplierFilter(db);
                }

                // Отображаем товары
                DisplayProducts(_allProducts);

                // Обновляем строку состояния
                TbStatus.Text = $"Товаров: {_allProducts.Count}";
            }
            catch (Exception ex)
            {
                // Обработка исключений: показываем сообщение, но не "падаем"
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                TbStatus.Text = "Ошибка загрузки";
            }
        }

        /// <summary>
        /// Заполняет выпадающий список поставщиков для фильтра.
        /// Первый элемент всегда "Все поставщики" (сбрасывает фильтр).
        /// </summary>
        private void LoadSupplierFilter(ShoeStoreContext db)
        {
            // Очищаем список
            CmbSupplier.Items.Clear();

            // Добавляем первый элемент "Все поставщики"
            CmbSupplier.Items.Add("Все поставщики");

            // Select() — проекция: из каждой сущности Supplier берём только Name
            // Distinct() — убираем дубликаты (на случай, если есть одинаковые имена)
            // ToList() — материализуем в список строк
            var suppliers = db.Suppliers
                .Select(s => s.Name)
                .Distinct()
                .OrderBy(s => s)
                .ToList();

            // Добавляем поставщиков в комбобокс
            foreach (var supplier in suppliers)
            {
                CmbSupplier.Items.Add(supplier);
            }

            // Выбираем первый элемент ("Все поставщики")
            CmbSupplier.SelectedIndex = 0;
        }

        /// <summary>
        /// Отображает список товаров в ItemsControl.
        /// Формат карточки — горизонтальный, согласно макету:
        /// [Фото] | [Категория + Наименование] | [Описание] | [Производитель] | [Поставщик] | [Цена] | [Ед.изм] | [Кол-во] | [Скидка]
        /// </summary>
        private void DisplayProducts(List<Product> products)
        {
            // Очищаем ItemsControl от старых элементов
            ItemsProducts.Items.Clear();

            foreach (var product in products)
            {
                // ===== СОЗДАНИЕ ОСНОВНОГО КОНТЕЙНЕРА (Border) =====
                var border = new Border
                {
                    Margin = new Thickness(5),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(200, 200, 200)),
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(5),
                    Padding = new Thickness(10)
                };

                // ===== УСЛОВНОЕ ФОРМАТИРОВАНИЕ ФОНА =====
                if (product.StockQuantity == 0)
                {
                    // Товара нет на складе — голубой фон
                    border.Background = new SolidColorBrush(Color.FromRgb(173, 216, 230));
                }
                else if (product.Discount > 15)
                {
                    // Скидка > 15% — зелёный фон #2E8B57
                    border.Background = new SolidColorBrush(Color.FromRgb(46, 139, 87));
                }
                else
                {
                    // Обычный белый фон
                    border.Background = Brushes.White;
                }

                // ===== ГОРИЗОНТАЛЬНЫЙ STACKPANEL — ОСНОВНАЯ СТРУКТУРА =====
                var mainStack = new StackPanel
                {
                    Orientation = Orientation.Horizontal
                };

                // ==========================================
                // БЛОК 1: ФОТО ТОВАРА
                // ==========================================
                var photoImage = new Image
                {
                    Width = 100,
                    Height = 100,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(0, 0, 15, 0)
                };
                LoadProductImage(photoImage, product.ImagePath);
                mainStack.Children.Add(photoImage);

                // ==========================================
                // БЛОК 2: ВЕРТИКАЛЬНАЯ ПАНЕЛЬ С ИНФОРМАЦИЕЙ
                // ==========================================
                var infoPanel = new StackPanel
                {
                    Orientation = Orientation.Vertical,
                    VerticalAlignment = VerticalAlignment.Center
                };

                // --- Строка 1: Категория + Наименование (горизонтально) ---
                var headerPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 0, 0, 3)
                };

                var categoryTextBlock = new TextBlock
                {
                    Text = product.Category?.Name ?? "Без категории",
                    FontWeight = FontWeights.Bold,
                    FontSize = 14,
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100)),
                    Margin = new Thickness(0, 0, 10, 0)
                };
                headerPanel.Children.Add(categoryTextBlock);

                var nameTextBlock = new TextBlock
                {
                    Text = product.Name,
                    FontWeight = FontWeights.Bold,
                    FontSize = 14
                };
                headerPanel.Children.Add(nameTextBlock);

                infoPanel.Children.Add(headerPanel);

                // --- Строка 2: Описание ---
                var descTextBlock = new TextBlock
                {
                    Text = $"Описание: {product.Description ?? "—"}",
                    FontSize = 12,
                    Foreground = new SolidColorBrush(Color.FromRgb(80, 80, 80)),
                    TextTrimming = TextTrimming.CharacterEllipsis,
                    MaxWidth = 400,
                    Margin = new Thickness(0, 0, 0, 3)
                };
                infoPanel.Children.Add(descTextBlock);

                // --- Строка 3: Производитель ---
                var manufacturerTextBlock = new TextBlock
                {
                    Text = $"Производитель: {product.Manufacturer?.Name ?? "—"}",
                    FontSize = 12,
                    Margin = new Thickness(0, 0, 0, 3)
                };
                infoPanel.Children.Add(manufacturerTextBlock);

                // --- Строка 4: Поставщик ---
                var supplierTextBlock = new TextBlock
                {
                    Text = $"Поставщик: {product.Supplier?.Name ?? "—"}",
                    FontSize = 12,
                    Margin = new Thickness(0, 0, 0, 3)
                };
                infoPanel.Children.Add(supplierTextBlock);

                // --- Строка 5: Цена (с учётом скидки) ---
                var pricePanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 0, 0, 3)
                };

                if (product.Discount > 0)
                {
                    // Старая цена (перечёркнутая, красная)
                    var oldPrice = new TextBlock
                    {
                        Text = $"{product.Price:N2} ₽",
                        TextDecorations = TextDecorations.Strikethrough,
                        Foreground = Brushes.Red,
                        FontSize = 12
                    };
                    pricePanel.Children.Add(oldPrice);

                    // Новая цена со скидкой
                    decimal discountedPrice = product.Price * (100 - product.Discount) / 100;
                    var newPrice = new TextBlock
                    {
                        Text = $" {discountedPrice:N2} ₽",
                        FontWeight = FontWeights.Bold,
                        FontSize = 13,
                        Margin = new Thickness(5, 0, 0, 0)
                    };
                    pricePanel.Children.Add(newPrice);
                }
                else
                {
                    // Обычная цена
                    var price = new TextBlock
                    {
                        Text = $"Цена: {product.Price:N2} ₽",
                        FontSize = 12
                    };
                    pricePanel.Children.Add(price);
                }
                infoPanel.Children.Add(pricePanel);

                // --- Строка 6: Единица измерения ---
                var unitTextBlock = new TextBlock
                {
                    Text = $"Единица измерения: {product.Unit}",
                    FontSize = 12,
                    Margin = new Thickness(0, 0, 0, 3)
                };
                infoPanel.Children.Add(unitTextBlock);

                // --- Строка 7: Количество на складе ---
                var quantityTextBlock = new TextBlock
                {
                    Text = $"Количество на складе: {product.StockQuantity}",
                    FontSize = 12,
                    Foreground = product.StockQuantity == 0
                        ? Brushes.Red
                        : new SolidColorBrush(Color.FromRgb(0, 100, 0))
                };
                infoPanel.Children.Add(quantityTextBlock);

                // Добавляем информационную панель в основной стек
                mainStack.Children.Add(infoPanel);

                // ==========================================
                // БЛОК 3: СКИДКА (отдельный блок справа)
                // ==========================================
                var discountPanel = new StackPanel
                {
                    Orientation = Orientation.Vertical,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(20, 0, 10, 0)
                };

                if (product.Discount > 0)
                {
                    // Иконка скидки
                    var discountBadge = new Border
                    {
                        Background = new SolidColorBrush(Color.FromRgb(220, 50, 50)),
                        CornerRadius = new CornerRadius(3),
                        Padding = new Thickness(8, 3, 8, 3),
                        HorizontalAlignment = HorizontalAlignment.Center
                    };

                    var discountText = new TextBlock
                    {
                        Text = $"-{product.Discount}%",
                        Foreground = Brushes.White,
                        FontWeight = FontWeights.Bold,
                        FontSize = 14
                    };
                    discountBadge.Child = discountText;
                    discountPanel.Children.Add(discountBadge);

                    // Текст "Действующая скидка"
                    var discountLabel = new TextBlock
                    {
                        Text = "Действующая\nскидка",
                        FontSize = 11,
                        Foreground = new SolidColorBrush(Color.FromRgb(120, 120, 120)),
                        TextAlignment = TextAlignment.Center,
                        Margin = new Thickness(0, 5, 0, 0)
                    };
                    discountPanel.Children.Add(discountLabel);
                }
                else
                {
                    // Нет скидки — пустое место или прочерк
                    var noDiscount = new TextBlock
                    {
                        Text = "—",
                        FontSize = 14,
                        Foreground = new SolidColorBrush(Color.FromRgb(180, 180, 180)),
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    discountPanel.Children.Add(noDiscount);
                }

                mainStack.Children.Add(discountPanel);

                // ==========================================
                // БЛОК 4: КНОПКИ ДЕЙСТВИЙ (только для админа)
                // ==========================================
                if (IsCurrentUserAdmin())
                {
                    var actionPanel = new StackPanel
                    {
                        Orientation = Orientation.Vertical,
                        VerticalAlignment = VerticalAlignment.Center,
                        Margin = new Thickness(15, 0, 0, 0)
                    };

                    var editButton = new Button
                    {
                        Content = "✎ Изменить",
                        Width = 100,
                        Height = 30,
                        FontSize = 12,
                        Background = new SolidColorBrush(Color.FromRgb(70, 130, 180)),
                        Foreground = Brushes.White,
                        Tag = product,
                        Cursor = Cursors.Hand,
                        Margin = new Thickness(0, 0, 0, 5)
                    };
                    editButton.Click += EditButton_Click;
                    actionPanel.Children.Add(editButton);

                    var deleteButton = new Button
                    {
                        Content = "✕ Удалить",
                        Width = 100,
                        Height = 30,
                        FontSize = 12,
                        Background = new SolidColorBrush(Color.FromRgb(200, 60, 60)),
                        Foreground = Brushes.White,
                        Tag = product,
                        Cursor = Cursors.Hand
                    };
                    deleteButton.Click += DeleteButton_Click;
                    actionPanel.Children.Add(deleteButton);

                    mainStack.Children.Add(actionPanel);
                }

                // ===== ЗАВЕРШЕНИЕ: ПОМЕЩАЕМ ВСЁ В BORDER =====
                border.Child = mainStack;
                ItemsProducts.Items.Add(border);
            }
        }

        /// <summary>
        /// Загружает изображение товара в контрол Image.
        /// При ошибке или отсутствии пути загружает заглушку.
        /// </summary>
        private void LoadProductImage(Image imageControl, string imagePath)
        {
            try
            {
                if (string.IsNullOrEmpty(imagePath))
                {
                    // Путь не указан — загружаем заглушку
                    imageControl.Source = new BitmapImage(
                        new Uri("pack://application:,,,/Resourses/picture.png"));
                }
                else
                {
                    // Пытаемся загрузить из папки Images
                    string fullPath = System.IO.Path.Combine(
                        AppDomain.CurrentDomain.BaseDirectory, "Images", imagePath);
                    if (System.IO.File.Exists(fullPath))
                    {
                        imageControl.Source = new BitmapImage(new Uri(fullPath));
                    }
                    else
                    {
                        // Файл не найден — заглушка
                        imageControl.Source = new BitmapImage(
                            new Uri("pack://application:,,,/Resourses/picture.png"));
                    }
                }
            }
            catch
            {
                // Любая ошибка — заглушка
                imageControl.Source = new BitmapImage(
                    new Uri("pack://application:,,,/Resourses/picture.png"));
            }
        }

        /// <summary>
        /// Настраивает видимость элементов интерфейса в зависимости от роли пользователя.
        /// </summary>
        private void SetupUserInterface()
        {
            // Если CurrentUser == null — это гость
            if (App.CurrentUser == null)
            {
                TbUserName.Text = "👤 Гость";
                // Скрываем панель поиска
                SearchPanel.Visibility = Visibility.Collapsed;
                // Скрываем панель фильтров
                FilterPanel.Visibility = Visibility.Collapsed;
                // Скрываем кнопки Заказов и Добавления
                BtnOrders.Visibility = Visibility.Collapsed;
                BtnAddProduct.Visibility = Visibility.Collapsed;
                return;
            }

            // Пользователь авторизован — показываем ФИО
            TbUserName.Text = $"👤 {App.CurrentUser.FullName}";

            // Проверяем роль через словарь
            bool isManagerOrAdmin = ManagerOrAdminRoles.ContainsKey(App.CurrentUser.RoleId);

            // Видимость поиска и фильтров
            SearchPanel.Visibility = isManagerOrAdmin ? Visibility.Visible : Visibility.Collapsed;
            FilterPanel.Visibility = isManagerOrAdmin ? Visibility.Visible : Visibility.Collapsed;

            // Видимость кнопки "Заказы"
            BtnOrders.Visibility = isManagerOrAdmin ? Visibility.Visible : Visibility.Collapsed;

            // Видимость кнопки "Добавить товар" (только Админ)
            BtnAddProduct.Visibility = IsCurrentUserAdmin() ? Visibility.Visible : Visibility.Collapsed;
        }

        /// <summary>
        /// Проверяет, является ли текущий пользователь администратором.
        /// RoleId == 1 — администратор.
        /// </summary>
        private bool IsCurrentUserAdmin()
        {
            return App.CurrentUser != null && App.CurrentUser.RoleId == 1;
        }

        // ========== ПОИСК, ФИЛЬТРАЦИЯ, СОРТИРОВКА ==========

        /// <summary>
        /// Обработчик изменения текста в поисковой строке.
        /// Срабатывает при КАЖДОМ нажатии клавиши (реал-тайм поиск).
        /// </summary>
        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFiltersAndSort();
        }

        /// <summary>
        /// Обработчик изменения выбранного поставщика в фильтре.
        /// </summary>
        private void CmbSupplier_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Игнорируем событие, если данные ещё не загружены
            if (_allProducts == null) return;

            ApplyFiltersAndSort();
        }

        /// <summary>
        /// Обработчик изменения сортировки.
        /// </summary>
        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_allProducts == null) return;

            ApplyFiltersAndSort();
        }

        /// <summary>
        /// Применяет все фильтры, поиск и сортировку совместно.
        /// Ключевая логика: фильтрация и сортировка применяются в памяти
        /// (над списком _allProducts), без дополнительных запросов к БД.
        /// </summary>
        private void ApplyFiltersAndSort()
        {
            if (_allProducts == null) return;

            // Начинаем с полного списка.
            // AsEnumerable() преобразует в IEnumerable<Product> для LINQ-to-Objects
            IEnumerable<Product> filtered = _allProducts.AsEnumerable();

            // ===== ЭТАП 1: ПОИСК ПО ВСЕМ ТЕКСТОВЫМ ПОЛЯМ =====
            string searchTerm = TbSearch.Text?.Trim().ToLower() ?? "";

            if (!string.IsNullOrEmpty(searchTerm))
            {
                // Where с лямбда-выражением — фильтрация.
                // Проверяем ВСЕ текстовые поля через оператор || (ИЛИ).
                // Contains() — метод строки, проверяет вхождение подстроки.
                // ?. — null-conditional оператор: если свойство null, возвращает null, не вызывая метод
                // ?? false — если слева null, возвращает false
                filtered = filtered.Where(p =>
                    (p.Name?.ToLower().Contains(searchTerm) ?? false) ||
                    (p.Description?.ToLower().Contains(searchTerm) ?? false) ||
                    (p.Article?.ToLower().Contains(searchTerm) ?? false) ||
                    (p.Category?.Name?.ToLower().Contains(searchTerm) ?? false) ||
                    (p.Manufacturer?.Name?.ToLower().Contains(searchTerm) ?? false) ||
                    (p.Supplier?.Name?.ToLower().Contains(searchTerm) ?? false)
                );
            }

            // ===== ЭТАП 2: ФИЛЬТР ПО ПОСТАВЩИКУ =====
            // Если выбран НЕ "Все поставщики" (индекс > 0)
            if (CmbSupplier.SelectedIndex > 0)
            {
                string selectedSupplier = CmbSupplier.SelectedItem.ToString();
                // Where фильтрует: оставляем только товары выбранного поставщика
                filtered = filtered.Where(p => p.Supplier?.Name == selectedSupplier);
            }

            // ===== ЭТАП 3: СОРТИРОВКА =====
            // Получаем выбранный ComboBoxItem
            if (CmbSort.SelectedItem is ComboBoxItem selectedSortItem)
            {
                string sortTag = selectedSortItem.Tag.ToString();

                // OrderBy / OrderByDescending — сортировка по ключу
                // p => p.StockQuantity — лямбда для извлечения ключа сортировки
                filtered = sortTag switch
                {
                    "Asc" => filtered.OrderBy(p => p.StockQuantity),
                    "Desc" => filtered.OrderByDescending(p => p.StockQuantity),
                    _ => filtered  // "None" — не сортируем
                };
            }

            // ===== ЭТАП 4: ОТОБРАЖЕНИЕ =====
            // ToList() материализует LINQ-запрос в List<Product> и отображает
            DisplayProducts(filtered.ToList());

            // Обновляем строку состояния
            TbStatus.Text = $"Найдено товаров: {filtered.Count()}";
        }

        // ========== ОБРАБОТЧИКИ КНОПОК ==========

        /// <summary>
        /// Обработчик кнопки "Редактировать" у товара.
        /// </summary>
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Извлекаем Product из свойства Tag кнопки
            var product = (sender as Button)?.Tag as Product;
            if (product == null) return;

            OpenEditProductWindow(product);
        }

        /// <summary>
        /// Обработчик кнопки "Удалить" у товара.
        /// </summary>
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var product = (sender as Button)?.Tag as Product;
            if (product == null) return;

            DeleteProduct(product);
        }

        /// <summary>
        /// Открывает окно редактирования товара.
        /// Защита: нельзя открыть больше одного окна редактирования.
        /// </summary>
        private void OpenEditProductWindow(Product product)
        {
            if (_isEditWindowOpen)
            {
                MessageBox.Show(
                    "Окно редактирования уже открыто. Закройте его перед открытием нового.",
                    "Предупреждение",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            _isEditWindowOpen = true;

            // Создаём окно редактирования (Product передаётся для редактирования)
            var editWindow = new AddEditProductWindow(product);

            // Подписываемся на событие Closed — когда окно закроется
            editWindow.Closed += (s, args) =>
            {
                _isEditWindowOpen = false;
                // Перезагружаем данные, чтобы отобразить изменения
                LoadProducts();
            };

            // ShowDialog() — модальное окно (блокирует родительское)
            editWindow.ShowDialog();
        }

        /// <summary>
        /// Удаляет товар с проверкой на наличие в заказах.
        /// </summary>
        private void DeleteProduct(Product product)
        {
            // MessageBox с кнопками Yes/No — подтверждение удаления
            var result = MessageBox.Show(
                $"Вы действительно хотите удалить товар \"{product.Name}\" (артикул: {product.Article})?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes) return;

            try
            {
                using (var db = new ShoeStoreContext())
                {
                    // Проверяем, есть ли товар в заказах
                    // Any() — LINQ-метод, возвращает true если есть хотя бы один элемент
                    bool inOrders = db.OrderItems.Any(oi => oi.ProductArticle == product.Article);

                    if (inOrders)
                    {
                        MessageBox.Show(
                            "Невозможно удалить товар: он присутствует в существующих заказах.",
                            "Ошибка удаления",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);
                        return;
                    }

                    // Находим товар в текущем контексте и удаляем
                    var productToDelete = db.Products.Find(product.Article);
                    if (productToDelete != null)
                    {
                        // Удаляем файл изображения с диска
                        DeleteImageFile(productToDelete.ImagePath);

                        db.Products.Remove(productToDelete);
                        db.SaveChanges();
                    }
                }

                // Перезагружаем список
                LoadProducts();

                TbStatus.Text = $"Товар \"{product.Name}\" успешно удалён";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при удалении товара: {ex.Message}",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Удаляет файл изображения с диска.
        /// </summary>
        private void DeleteImageFile(string imagePath)
        {
            if (string.IsNullOrEmpty(imagePath)) return;

            try
            {
                string fullPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, "Images", imagePath);

                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
            }
            catch
            {
                // Игнорируем ошибки удаления файла (не критично)
            }
        }

        /// <summary>
        /// Обработчик кнопки "Добавить товар".
        /// </summary>
        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            if (_isEditWindowOpen)
            {
                MessageBox.Show("Сначала закройте текущее окно редактирования.",
                    "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _isEditWindowOpen = true;

            // Передаём null — режим добавления
            var addWindow = new AddEditProductWindow(null);
            addWindow.Closed += (s, args) =>
            {
                _isEditWindowOpen = false;
                LoadProducts();
            };
            addWindow.ShowDialog();
        }

        /// <summary>
        /// Обработчик кнопки "Заказы".
        /// </summary>
        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            var ordersWindow = new OrdersWindow();
            ordersWindow.ShowDialog();  // Модальное окно
        }

        /// <summary>
        /// Обработчик кнопки "Выход".
        /// Сбрасывает текущего пользователя и возвращает на окно входа.
        /// </summary>
        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            // Сбрасываем пользователя
            App.CurrentUser = null;

            // Создаём новое окно входа
            var loginWindow = new LoginWindow();
            loginWindow.Show();

            // Закрываем текущее окно
            this.Close();
        }
    }
}
