﻿using ShoeStore.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShoeStore.Views
{
    /// <summary>
    /// Окно авторизации пользователя.
    /// Первое окно, которое видит пользователь при запуске приложения.
    /// </summary>
    public partial class LoginWindow : Window
    {
        /// <summary>
        /// Конструктор окна.
        /// InitializeComponent() — метод, сгенерированный из XAML-разметки.
        /// Он создаёт все контролы, задаёт им свойства и привязывает обработчики.
        /// </summary>
        public LoginWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Войти".
        /// Выполняет аутентификацию пользователя по логину и паролю.
        /// </summary>
        /// <param name="sender">Объект, вызвавший событие (кнопка)</param>
        /// <param name="e">Аргументы события (не используются)</param>
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            // Получаем введённые значения
            string login = TbLogin.Text.Trim();        // Trim() убирает пробелы в начале и конце
            string password = PbPassword.Password;      // У PasswordBox нет Text, только Password

            // Валидация: проверяем, что поля не пустые
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                TbError.Text = "Введите логин и пароль";
                return;  // Прерываем выполнение метода
            }

            // Создаём контекст БД внутри using для автоматического освобождения ресурсов
            using (var db = new ShoeStoreContext())
            {
                // LINQ-запрос: ищем пользователя с совпадающим логином И паролем
                // FirstOrDefault() возвращает первый найденный элемент или null, если не найдено
                // Лямбда-выражение u => u.Login == login && u.Password == password —
                // это предикат (функция, возвращающая bool) для фильтрации
                var user = db.Users.FirstOrDefault(u => u.Login == login && u.Password == password);

                // Проверяем, нашёлся ли пользователь
                if (user == null)
                {
                    TbError.Text = "Неверный логин или пароль";
                    return;
                }

                // Аутентификация успешна:
                // 1. Сохраняем пользователя в статическое свойство App.CurrentUser
                App.CurrentUser = user;

                // 2. Открываем главное окно и закрываем текущее
                OpenMainWindow();
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Продолжить как гость".
        /// Устанавливает CurrentUser в null и открывает главное окно.
        /// </summary>
        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            // Устанавливаем null — признак гостя
            App.CurrentUser = null;

            // Открываем главное окно
            OpenMainWindow();
        }

        /// <summary>
        /// Вспомогательный метод: открывает главное окно и закрывает текущее.
        /// Вынесен в отдельный метод, чтобы избежать дублирования кода.
        /// </summary>
        private void OpenMainWindow()
        {
            // Создаём экземпляр главного окна
            var mainWindow = new MainWindow();

            // Show() — открывает окно и продолжает выполнение кода
            mainWindow.Show();

            // Close() — закрывает текущее окно (LoginWindow)
            this.Close();
        }
    }
}
