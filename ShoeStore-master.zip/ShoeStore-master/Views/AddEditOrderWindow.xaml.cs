﻿using ShoeStore.Data;
using ShoeStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShoeStore.Views
{
    /// <summary>
    /// Логика взаимодействия для AddEditOrderWindow.xaml
    /// </summary>
    public partial class AddEditOrderWindow : Window
    {
        private Order _order;  // null = добавление, не null = редактирование

        public AddEditOrderWindow(Order order)
        {
            InitializeComponent();
            DpOrderDate.SelectedDate = DateTime.Now;
            _order = order;

            // Загружаем данные в выпадающие списки
            LoadDropdowns();

            if (order != null)
            {
                // ===== РЕЖИМ РЕДАКТИРОВАНИЯ =====
                TbTitle.Text = "Редактирование заказа";
                DpOrderDate.SelectedDate = order.OrderDate;
                DpDeliveryDate.SelectedDate = order.DeliveryDate;
                TbCode.Text = order.Code;

                // Выбираем нужные значения в ComboBox
                SelectUserById(order.UserId);
                SelectPickupPointById(order.PickupPointId);
                SelectStatus(order.Status);
            }
        }

        /// <summary>
        /// Загружает списки пользователей и пунктов выдачи.
        /// </summary>
        private void LoadDropdowns()
        {
            using (var db = new ShoeStoreContext())
            {
                // Загружаем клиентов (RoleId == 3)
                var clients = db.Users
                    .Where(u => u.RoleId == 3)  // Только клиенты, не менеджеры и админы
                    .OrderBy(u => u.FullName)
                    .ToList();
                CmbUser.ItemsSource = clients;
                CmbUser.DisplayMemberPath = "FullName";

                // Загружаем пункты выдачи
                var points = db.PickupPoints
                    .OrderBy(p => p.Address)
                    .ToList();
                CmbPickupPoint.ItemsSource = points;
                CmbPickupPoint.DisplayMemberPath = "Address";
            }
        }

        /// <summary>
        /// Выбирает пользователя по ID в ComboBox.
        /// </summary>
        private void SelectUserById(int userId)
        {
            foreach (var item in CmbUser.Items)
            {
                if (item is User user && user.Id == userId)
                {
                    CmbUser.SelectedItem = item;
                    return;
                }
            }
        }

        /// <summary>
        /// Выбирает пункт выдачи по ID в ComboBox.
        /// </summary>
        private void SelectPickupPointById(int pointId)
        {
            foreach (var item in CmbPickupPoint.Items)
            {
                if (item is PickupPoint point && point.Id == pointId)
                {
                    CmbPickupPoint.SelectedItem = item;
                    return;
                }
            }
        }

        /// <summary>
        /// Выбирает статус в ComboBox.
        /// </summary>
        private void SelectStatus(string status)
        {
            foreach (ComboBoxItem item in CmbStatus.Items)
            {
                if (item.Content.ToString() == status)
                {
                    CmbStatus.SelectedItem = item;
                    return;
                }
            }
        }

        /// <summary>
        /// Сохранение заказа.
        /// </summary>
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (!ValidateInput(out string error))
            {
                TbError.Text = error;
                return;
            }

            try
            {
                using (var db = new ShoeStoreContext())
                {
                    if (_order == null)
                    {
                        // ===== ДОБАВЛЕНИЕ =====
                        _order = new Order();
                        db.Orders.Add(_order);
                    }
                    else
                    {
                        // ===== РЕДАКТИРОВАНИЕ =====
                        db.Orders.Attach(_order);
                    }

                    _order.OrderDate = DpOrderDate.SelectedDate.Value;
                    _order.DeliveryDate = DpDeliveryDate.SelectedDate.Value;
                    _order.UserId = ((User)CmbUser.SelectedItem).Id;
                    _order.PickupPointId = ((PickupPoint)CmbPickupPoint.SelectedItem).Id;
                    _order.Code = TbCode.Text.Trim();
                    _order.Status = ((ComboBoxItem)CmbStatus.SelectedItem).Content.ToString();

                    db.SaveChanges();
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                TbError.Text = $"Ошибка сохранения: {ex.Message}";
            }
        }

        /// <summary>
        /// Валидация введённых данных.
        /// </summary>
        private bool ValidateInput(out string error)
        {
            if (DpOrderDate.SelectedDate == null) { error = "Выберите дату заказа"; return false; }
            if (DpDeliveryDate.SelectedDate == null) { error = "Выберите дату доставки"; return false; }
            if (CmbUser.SelectedItem == null) { error = "Выберите клиента"; return false; }
            if (CmbPickupPoint.SelectedItem == null) { error = "Выберите пункт выдачи"; return false; }
            if (string.IsNullOrWhiteSpace(TbCode.Text)) { error = "Введите код получения"; return false; }
            error = null;
            return true;
        }

        /// <summary>
        /// Отмена.
        /// </summary>
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
