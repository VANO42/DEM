﻿using Microsoft.EntityFrameworkCore;
using ShoeStore.Data;
using ShoeStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShoeStore.Views
{
    /// <summary>
    /// Логика взаимодействия для OrdersWindow.xaml
    /// </summary>
    /// <summary>
    /// Окно просмотра и управления заказами.
    /// Доступно Менеджеру (только просмотр) и Администратору (полный доступ).
    /// </summary>
    public partial class OrdersWindow : Window
    {
        public OrdersWindow()
        {
            InitializeComponent();
            SetupAccessRights();
            LoadOrders();
        }

        /// <summary>
        /// Настраивает видимость кнопок в зависимости от роли.
        /// Админ видит кнопки "Добавить заказ" и действия.
        /// Менеджер — только просмотр.
        /// </summary>
        private void SetupAccessRights()
        {
            bool isAdmin = App.CurrentUser != null && App.CurrentUser.RoleId == 1;

            // Кнопка "Добавить заказ" в верхней панели
            BtnAddOrder.Visibility = isAdmin ? Visibility.Visible : Visibility.Collapsed;

            // Кнопки действий скрываем через ItemContainerGenerator после загрузки
            // или проще — через событие Loaded каждого элемента
        }

        /// <summary>
        /// Загружает заказы из БД и привязывает к ItemsControl.
        /// </summary>
        private void LoadOrders()
        {
            try
            {
                using (var db = new ShoeStoreContext())
                {
                    var orders = db.Orders
                        .Include(o => o.PickupPoint)
                        .Include(o => o.User)
                        .Include(o => o.OrderItems)
                        .OrderByDescending(o => o.OrderDate)
                        .ToList();

                    ItemsOrders.ItemsSource = orders;
                }

                TbStatus.Text = $"Всего заказов: {ItemsOrders.Items.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Кнопка "Добавить заказ".
        /// </summary>
        private void BtnAddOrder_Click(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddEditOrderWindow(null);
            addWindow.Owner = this;
            if (addWindow.ShowDialog() == true)
                LoadOrders();
        }

        /// <summary>
        /// Кнопка "Обновить".
        /// </summary>
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        /// <summary>
        /// Кнопка "Редактировать" в строке заказа.
        /// Извлекает заказ из Tag кнопки.
        /// </summary>
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Order order)
            {
                var editWindow = new AddEditOrderWindow(order);
                editWindow.Owner = this;
                if (editWindow.ShowDialog() == true)
                    LoadOrders();
            }
        }

        /// <summary>
        /// Кнопка "Удалить" в строке заказа.
        /// </summary>
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Order order)
            {
                var result = MessageBox.Show(
                    $"Удалить заказ №{order.Id}?\n\n" +
                    $"Клиент: {order.User?.FullName}\n" +
                    $"Дата: {order.OrderDate:dd.MM.yyyy}\n" +
                    $"Статус: {order.Status}",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result != MessageBoxResult.Yes) return;

                try
                {
                    using (var db = new ShoeStoreContext())
                    {
                        var orderToDelete = db.Orders.Find(order.Id);
                        if (orderToDelete != null)
                        {
                            db.Orders.Remove(orderToDelete);
                            db.SaveChanges();
                        }
                    }
                    LoadOrders();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
