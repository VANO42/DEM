﻿using ShoeStore.Data;
using ShoeStore.Models;
using System.Configuration;
using System.Data;
using System.Windows;

namespace ShoeStore
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Текущий пользователь (null = гость)
        public static User? CurrentUser { get; set; }

        // Контекст БД (создаётся один раз)
        public static ShoeStoreContext DbContext => new ShoeStoreContext();
    }

}
