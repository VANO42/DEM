﻿using System;
using System.Collections.Generic;

namespace ShoeStore.Models;

public partial class Product
{
    public string Article { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Unit { get; set; } = null!;

    public decimal Price { get; set; }

    public int Discount { get; set; }

    public int StockQuantity { get; set; }

    public string? Description { get; set; }

    public string? ImagePath { get; set; }

    public int? CategoryId { get; set; }

    public int? SupplierId { get; set; }

    public int? ManufacturerId { get; set; }

    public virtual Category? Category { get; set; }

    public virtual Manufacturer? Manufacturer { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    public virtual Supplier? Supplier { get; set; }
}
